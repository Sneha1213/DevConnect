import React, { Fragment } from "react";
// import spinner from './spinner.gif';

export default () => (
    <Fragment>
        <img
            src="https://s3.us-east-2.amazonaws.com/models-virtual-drive/upload/adiskwt325@gmail.comAdityaspinner.gif"
            style={{ width: '200px', margin: 'auto', display: 'block' }}
            alt='Loading...'
        />
    </Fragment>
);